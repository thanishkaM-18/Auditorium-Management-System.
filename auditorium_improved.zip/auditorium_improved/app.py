from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify, Response, flash)
import sqlite3, os, csv, io
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-in-production"
DB = "auditorium.db"


# ========== DB HELPERS ==========
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS auditoriums (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        name TEXT,
        total_seats INTEGER
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS checkins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        auditorium_code TEXT,
        reg_no TEXT,
        created_at TEXT,
        event_id INTEGER
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        auditorium_code TEXT,
        start_time TEXT,
        end_time TEXT
    )""")

    c.execute("""
    CREATE TABLE IF NOT EXISTS reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id INTEGER,
        auditorium_code TEXT,
        seat_number INTEGER,
        reg_no TEXT,
        created_at TEXT
    )""")

    try:
        c.execute("ALTER TABLE checkins ADD COLUMN event_id INTEGER")
    except sqlite3.OperationalError:
        pass

    conn.commit()
    conn.close()


def is_admin():
    return session.get("logged_in") is True


def clear_expired_reservations(minutes=15):
    conn = get_db()
    c = conn.cursor()
    cutoff = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    c.execute("DELETE FROM reservations WHERE created_at < ?", (cutoff,))
    conn.commit()
    conn.close()


def event_status(start_time, end_time):
    try:
        now = datetime.now()
        start = datetime.strptime(start_time, "%Y-%m-%d %H:%M")
        end   = datetime.strptime(end_time,   "%Y-%m-%d %H:%M")
        if now < start:
            return "upcoming"
        elif now > end:
            return "past"
        else:
            return "ongoing"
    except Exception:
        return "unknown"


# ========== AUTH ==========
@app.route("/")
def index():
    if is_admin():
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("login"))


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not password:
            return render_template("signup.html", error="All fields are required.")
        hashed_pw = generate_password_hash(password)
        conn = get_db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_pw))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return render_template("signup.html", error="Username already exists.")
        conn.close()
        return redirect(url_for("login"))
    return render_template("signup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("admin_dashboard"))
        return render_template("login.html", error="Invalid username or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ========== ADMIN DASHBOARD ==========
@app.route("/admin")
def admin_dashboard():
    if not is_admin():
        return redirect(url_for("login"))

    clear_expired_reservations()
    now = datetime.now()

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM auditoriums")
    auds = c.fetchall()

    # Summary stats
    c.execute("SELECT COUNT(*) as cnt FROM events")
    total_events = c.fetchone()["cnt"]

    today_str = now.strftime("%Y-%m-%d")
    c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE created_at LIKE ?", (today_str + "%",))
    checkins_today = c.fetchone()["cnt"]

    total_seats = sum(a["total_seats"] for a in auds)

    auditoriums_data = []
    for aud in auds:
        c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE auditorium_code = ?", (aud["code"],))
        occupied = c.fetchone()["cnt"]
        c.execute("SELECT seat_number FROM reservations WHERE auditorium_code = ?", (aud["code"],))
        reserved_seats = [r["seat_number"] for r in c.fetchall()]
        available = max(0, aud["total_seats"] - occupied)
        occupancy_pct = round((occupied / aud["total_seats"]) * 100) if aud["total_seats"] > 0 else 0

        # recent checkins for this auditorium
        c.execute("""SELECT ci.reg_no, ci.created_at, e.title as event_title
                     FROM checkins ci LEFT JOIN events e ON ci.event_id = e.id
                     WHERE ci.auditorium_code = ?
                     ORDER BY ci.created_at DESC LIMIT 5""", (aud["code"],))
        recent = [dict(r) for r in c.fetchall()]

        auditoriums_data.append({
            "code": aud["code"],
            "name": aud["name"],
            "total": aud["total_seats"],
            "occupied": occupied,
            "available": available,
            "reserved_seats": reserved_seats,
            "occupancy_pct": occupancy_pct,
            "recent_checkins": recent
        })

    # Recent 10 checkins globally
    c.execute("""SELECT ci.reg_no, ci.created_at, ci.auditorium_code, e.title as event_title
                 FROM checkins ci LEFT JOIN events e ON ci.event_id = e.id
                 ORDER BY ci.created_at DESC LIMIT 10""")
    recent_activity = [dict(r) for r in c.fetchall()]

    conn.close()
    return render_template("admin_dashboard.html",
                           auditoriums=auditoriums_data,
                           total_events=total_events,
                           checkins_today=checkins_today,
                           total_seats=total_seats,
                           recent_activity=recent_activity)


@app.route("/admin/data")
def admin_data():
    if not is_admin():
        return jsonify({"error": "unauthorized"}), 401
    clear_expired_reservations()
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM auditoriums")
    auds = c.fetchall()
    result = []
    for aud in auds:
        c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE auditorium_code = ?", (aud["code"],))
        occupied = c.fetchone()["cnt"]
        c.execute("SELECT seat_number FROM reservations WHERE auditorium_code = ?", (aud["code"],))
        reserved = [r["seat_number"] for r in c.fetchall()]
        available = max(0, aud["total_seats"] - occupied)
        result.append({
            "code": aud["code"],
            "name": aud["name"],
            "total": aud["total_seats"],
            "occupied": occupied,
            "available": available,
            "reserved_seats": reserved,
            "occupancy_pct": round((occupied / aud["total_seats"]) * 100) if aud["total_seats"] > 0 else 0
        })
    conn.close()
    return jsonify(result)


# ========== ADD / RESET / DELETE AUDITORIUM ==========
@app.route("/admin/add", methods=["GET", "POST"])
def add_auditorium():
    if not is_admin():
        return redirect(url_for("login"))
    if request.method == "POST":
        aud_code = request.form.get("code", "").strip().upper()
        aud_name = request.form.get("name", "").strip()
        total_seats = int(request.form.get("total", 0))
        if not aud_code or not aud_name or total_seats < 1:
            return render_template("add_auditorium.html", error="All fields are required.")
        conn = get_db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO auditoriums (code, name, total_seats) VALUES (?, ?, ?)",
                      (aud_code, aud_name, total_seats))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return render_template("add_auditorium.html", error="Auditorium code already exists.")
        conn.close()
        return redirect(url_for("admin_dashboard"))
    return render_template("add_auditorium.html")


@app.route("/admin/reset", methods=["POST"])
def reset_auditorium():
    if not is_admin():
        return redirect(url_for("login"))
    aud_code = request.form.get("aud_code")
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM checkins WHERE auditorium_code = ?", (aud_code,))
    c.execute("DELETE FROM reservations WHERE auditorium_code = ?", (aud_code,))
    conn.commit()
    conn.close()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/delete", methods=["POST"])
def delete_auditorium():
    if not is_admin():
        return redirect(url_for("login"))
    aud_code = request.form.get("aud_code")
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM checkins WHERE auditorium_code = ?", (aud_code,))
    c.execute("DELETE FROM reservations WHERE auditorium_code = ?", (aud_code,))
    c.execute("DELETE FROM auditoriums WHERE code = ?", (aud_code,))
    conn.commit()
    conn.close()
    return redirect(url_for("admin_dashboard"))


# ========== EVENTS ==========
@app.route("/admin/events")
def admin_events():
    if not is_admin():
        return redirect(url_for("login"))
    search = request.args.get("q", "").strip()
    conn = get_db()
    c = conn.cursor()
    if search:
        c.execute("SELECT * FROM events WHERE title LIKE ? ORDER BY start_time DESC",
                  (f"%{search}%",))
    else:
        c.execute("SELECT * FROM events ORDER BY start_time DESC")
    events_raw = c.fetchall()

    events = []
    for e in events_raw:
        c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE event_id = ?", (e["id"],))
        checkin_count = c.fetchone()["cnt"]
        c.execute("SELECT total_seats FROM auditoriums WHERE code = ?", (e["auditorium_code"],))
        aud = c.fetchone()
        capacity = aud["total_seats"] if aud else 0
        events.append({
            "id": e["id"],
            "title": e["title"],
            "auditorium_code": e["auditorium_code"],
            "start_time": e["start_time"],
            "end_time": e["end_time"],
            "status": event_status(e["start_time"], e["end_time"]),
            "checkin_count": checkin_count,
            "capacity": capacity
        })

    c.execute("SELECT code, name FROM auditoriums")
    auds = c.fetchall()
    conn.close()
    return render_template("admin_events.html", events=events, auditoriums=auds, search=search)


@app.route("/admin/events/add", methods=["GET", "POST"])
def add_event():
    if not is_admin():
        return redirect(url_for("login"))
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT code, name FROM auditoriums")
    auds = c.fetchall()
    error = None
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        auditorium_code = request.form.get("auditorium_code")
        start_raw = request.form.get("start_time", "")
        end_raw   = request.form.get("end_time", "")
        # Accept datetime-local format (YYYY-MM-DDTHH:MM) and normalize
        start_time = start_raw.replace("T", " ") if "T" in start_raw else start_raw
        end_time   = end_raw.replace("T", " ")   if "T" in end_raw   else end_raw
        if not title or not auditorium_code or not start_time or not end_time:
            error = "All fields are required."
        else:
            c.execute("""INSERT INTO events (title, auditorium_code, start_time, end_time)
                         VALUES (?, ?, ?, ?)""", (title, auditorium_code, start_time, end_time))
            conn.commit()
            conn.close()
            return redirect(url_for("admin_events"))
    if error:
        conn.close()
        return render_template("add_event.html", auditoriums=auds, error=error)
    conn.close()
    return render_template("add_event.html", auditoriums=auds)


@app.route("/admin/events/<int:event_id>/delete", methods=["POST"])
def delete_event(event_id):
    if not is_admin():
        return redirect(url_for("login"))
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM reservations WHERE event_id = ?", (event_id,))
    c.execute("DELETE FROM events WHERE id = ?", (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("admin_events"))


# ========== CHECKINS LIST ==========
@app.route("/admin/checkins")
def admin_checkins():
    if not is_admin():
        return redirect(url_for("login"))
    aud_filter   = request.args.get("aud", "")
    event_filter = request.args.get("event", "")
    search       = request.args.get("q", "").strip()

    conn = get_db()
    c = conn.cursor()

    query = """SELECT ci.id, ci.reg_no, ci.created_at, ci.auditorium_code,
                      e.title as event_title, a.name as aud_name
               FROM checkins ci
               LEFT JOIN events e ON ci.event_id = e.id
               LEFT JOIN auditoriums a ON ci.auditorium_code = a.code
               WHERE 1=1"""
    params = []
    if aud_filter:
        query += " AND ci.auditorium_code = ?"
        params.append(aud_filter)
    if event_filter:
        query += " AND ci.event_id = ?"
        params.append(event_filter)
    if search:
        query += " AND ci.reg_no LIKE ?"
        params.append(f"%{search}%")
    query += " ORDER BY ci.created_at DESC LIMIT 200"

    c.execute(query, params)
    checkins = [dict(r) for r in c.fetchall()]

    c.execute("SELECT code, name FROM auditoriums")
    auds = c.fetchall()
    c.execute("SELECT id, title FROM events ORDER BY start_time DESC")
    events = c.fetchall()
    c.execute("SELECT COUNT(*) as cnt FROM checkins")
    total_checkins = c.fetchone()["cnt"]

    conn.close()
    return render_template("admin_checkins.html",
                           checkins=checkins,
                           auditoriums=auds,
                           events=events,
                           aud_filter=aud_filter,
                           event_filter=event_filter,
                           search=search,
                           total_checkins=total_checkins)


@app.route("/admin/export/checkins")
def export_checkins():
    if not is_admin():
        return redirect(url_for("login"))
    aud_filter   = request.args.get("aud", "")
    event_filter = request.args.get("event", "")

    conn = get_db()
    c = conn.cursor()
    query = """SELECT ci.id, ci.reg_no, ci.created_at, ci.auditorium_code,
                      e.title as event_title, a.name as aud_name
               FROM checkins ci
               LEFT JOIN events e ON ci.event_id = e.id
               LEFT JOIN auditoriums a ON ci.auditorium_code = a.code
               WHERE 1=1"""
    params = []
    if aud_filter:
        query += " AND ci.auditorium_code = ?"
        params.append(aud_filter)
    if event_filter:
        query += " AND ci.event_id = ?"
        params.append(event_filter)
    query += " ORDER BY ci.created_at DESC"
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Reg No", "Auditorium Code", "Auditorium Name", "Event", "Checked In At"])
    for r in rows:
        writer.writerow([r["id"], r["reg_no"], r["auditorium_code"],
                         r["aud_name"] or "", r["event_title"] or "", r["created_at"]])

    filename = f"checkins_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


# ========== STATS (JSON for charts) ==========
@app.route("/admin/stats")
def admin_stats():
    if not is_admin():
        return jsonify({"error": "unauthorized"}), 401

    conn = get_db()
    c = conn.cursor()

    # Checkins per day (last 7 days)
    days = []
    for i in range(6, -1, -1):
        d = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
        c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE created_at LIKE ?", (d + "%",))
        days.append({"date": d, "count": c.fetchone()["cnt"]})

    # Per auditorium occupancy
    c.execute("SELECT * FROM auditoriums")
    auds = c.fetchall()
    occupancy = []
    for a in auds:
        c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE auditorium_code = ?", (a["code"],))
        cnt = c.fetchone()["cnt"]
        occupancy.append({"name": a["name"], "occupied": cnt, "total": a["total_seats"]})

    conn.close()
    return jsonify({"daily": days, "occupancy": occupancy})


# ========== RESERVE ==========
@app.route("/reserve", methods=["GET", "POST"])
def reserve():
    aud_code = request.args.get("aud")
    event_id = request.args.get("event")
    if not aud_code or not event_id:
        return "Missing auditorium or event", 400

    clear_expired_reservations()
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM auditoriums WHERE code = ?", (aud_code,))
    auditorium = c.fetchone()
    c.execute("SELECT * FROM events WHERE id = ?", (event_id,))
    event = c.fetchone()
    if not auditorium or not event:
        conn.close()
        return "Invalid auditorium or event", 404

    c.execute("SELECT seat_number FROM reservations WHERE auditorium_code = ? AND event_id = ?",
              (aud_code, event_id))
    reserved_seats = [r["seat_number"] for r in c.fetchall()]

    error = success = None
    if request.method == "POST":
        reg_no  = request.form.get("reg_no", "").strip()
        seat_no_raw = request.form.get("seat_no", "")
        if not reg_no:
            error = "Registration number is required."
        elif not seat_no_raw:
            error = "Please select a seat."
        else:
            seat_no = int(seat_no_raw)
            if seat_no in reserved_seats:
                error = "Seat already reserved. Please choose another."
            else:
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                c.execute("""INSERT INTO reservations (event_id, auditorium_code, seat_number, reg_no, created_at)
                             VALUES (?, ?, ?, ?, ?)""", (event_id, aud_code, seat_no, reg_no, now))
                conn.commit()
                reserved_seats.append(seat_no)
                success = f"Seat {seat_no} reserved successfully for {reg_no}!"

    conn.close()
    return render_template("reserve.html",
                           auditorium=auditorium,
                           event=event,
                           reserved_seats=reserved_seats,
                           error=error,
                           success=success)


# ========== CHECK-IN ==========
@app.route("/checkin", methods=["GET", "POST"])
def checkin():
    aud_code = request.args.get("aud")
    if not aud_code:
        return "Auditorium not specified", 400

    clear_expired_reservations()
    conn = get_db()
    c = conn.cursor()

    c.execute("SELECT * FROM auditoriums WHERE code = ?", (aud_code,))
    auditorium = c.fetchone()
    if not auditorium:
        conn.close()
        return "Invalid auditorium", 404

    c.execute("SELECT COUNT(*) as cnt FROM checkins WHERE auditorium_code = ?", (aud_code,))
    occupied = c.fetchone()["cnt"]
    available = max(0, auditorium["total_seats"] - occupied)

    c.execute("SELECT id, title, start_time, end_time FROM events WHERE auditorium_code = ? ORDER BY start_time DESC",
              (aud_code,))
    events = [dict(r) for r in c.fetchall()]
    # Add status to each event
    for e in events:
        e["status"] = event_status(e["start_time"], e["end_time"])

    if request.method == "POST":
        reg_no   = request.form.get("reg_no", "").strip()
        event_id = request.form.get("event_id") or None

        if event_id:
            c.execute("""SELECT COUNT(*) as cnt FROM checkins
                         WHERE auditorium_code = ? AND reg_no = ? AND event_id = ?""",
                      (aud_code, reg_no, event_id))
        else:
            c.execute("""SELECT COUNT(*) as cnt FROM checkins
                         WHERE auditorium_code = ? AND reg_no = ?""", (aud_code, reg_no))

        if c.fetchone()["cnt"] > 0:
            conn.close()
            return render_template("checkin_result.html",
                                   message="You have already checked in for this event.",
                                   success=False, aud_code=aud_code)

        if available <= 0:
            conn.close()
            return render_template("checkin_result.html",
                                   message="No seats available in this auditorium.",
                                   success=False, aud_code=aud_code)

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""INSERT INTO checkins (auditorium_code, reg_no, created_at, event_id)
                     VALUES (?, ?, ?, ?)""", (aud_code, reg_no, timestamp, event_id))
        conn.commit()

        # Get event title for confirmation
        event_title = None
        if event_id:
            c.execute("SELECT title FROM events WHERE id = ?", (event_id,))
            ev = c.fetchone()
            event_title = ev["title"] if ev else None

        conn.close()

        csv_file = "checkins.csv"
        file_exists = os.path.isfile(csv_file)
        with open(csv_file, "a", newline="") as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(["timestamp", "auditorium_code", "registration_number", "event_id"])
            writer.writerow([timestamp, aud_code, reg_no, event_id])

        return render_template("checkin_result.html",
                               message=f"Check-in successful! Welcome, {reg_no}.",
                               success=True,
                               reg_no=reg_no,
                               event_title=event_title,
                               auditorium_name=auditorium["name"],
                               timestamp=timestamp,
                               aud_code=aud_code)

    conn.close()
    return render_template("checkin.html",
                           auditorium=auditorium,
                           available=available,
                           occupied=occupied,
                           events=events)


# ========== SCANNER ==========
@app.route("/scan")
def scan():
    return render_template("scan.html")


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0")
